//Title: Time, When It Gets Loud
//Author: XU CHENCHEN
//Date: 2026 Jan

//Description:
    //This project explores subjective experiences of time. A continuous 60-second time cycle forms the background, representing everyday, habitual time. Sound input (voice, noise, silence) influences this flow, causing moments of emotional intensity where time feels compressed, accelerated, or overwhelmed, but it always goes on.
    //Fragments of text in perpetual descent shift with the rhythm of sound, while the camera captures life's moments of laughter and shrieks. Like dopamine in tranquil times, they render time swift and erratic. Yet when all returns to stillness, the words vanish abruptly, and time resumes its drift and steady flow.

///Instructions:
    //A 60-second time cycle continuously runs in the background, visualised as a wave slowly moving from the bottom to the top of the screen.
    //Sound intensity affects the system:Louder sounds generate more falling text fragments and increase visual density.Silence gradually clears the text, returning the system to a calm state.
    //The webcam feed appears as a floating window that drifts across the canvas.






let mic;
let fft;
let hueStart = 0;

let soundThreshold = 0.009 //ume threshold for triggering text generation
let silenceCounter = 0;
let silenceLimit = 40;//detect text clearing during continuous silence.

let timeStart;
let timeDuration = 60 * 1000; // 60 seconds = one time loop
let currentTimeY = 0;


let fallingTexts = [];

let poemFragments = [
  "say something",
  "time slows down",
  "why we need friends",
  "the moment stretches",
  "memory piles up",
  "silence breaks it",
  "same day again",
  "laughing loudly"
];

// 摄像头漂浮
let cam;
let camBox = {
  x: 0,
  y: 0,
  w: 640,
  h: 480,
  vx: 0.5,
  vy: 0.3,
  scale: 1,
  
};

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 100);
  rectMode(CENTER);
  textAlign(LEFT, CENTER);
  textSize(20);
  noStroke();

  mic = new p5.AudioIn();
  mic.start();

  fft = new p5.FFT(0.8, 64);
  fft.setInput(mic);

  timeStart = millis();

  cam = createCapture(VIDEO);
  cam.hide();


  cam.size(camBox.w, camBox.h);
  camBox.x = width / 2;
  camBox.y = height / 2;
}

function draw() {
  let spectrum = fft.analyze();
  let amplitude = mic.getLevel();

  // Background + Spectrum
  drawVaporwaveSpectrum(spectrum, amplitude);

  // Using sound to generate poetry
  if (amplitude > soundThreshold) {
    silenceCounter = 0;

    if (frameCount % 4 === 0) {
      fallingTexts.push({
        x: random(80, width - 80),
        y: currentTimeY,

        vy: map(amplitude, 0, 0.3, 3, 6),
        text: random(poemFragments),
        hue: (hueStart + int(random(0, 64)) * 5) % 360,
        alpha: 100,
        trail: []
      });
    }
  } else {
    silenceCounter++;
  }

  if (silenceCounter > silenceLimit) {
    fallingTexts = [];
  }

  // update
  for (let i = fallingTexts.length - 1; i >= 0; i--) {
    let t = fallingTexts[i];
    t.trail.push({ x: t.x, y: t.y });
    if (t.trail.length > 3) t.trail.shift();

    t.y += t.vy;
    if (t.y > height - 80) {
      t.y = height - 80;
      t.vy = 0;
    }

    // 残影
    for (let j = 0; j < t.trail.length; j++) {
      let p = t.trail[j];
      let a = map(j, 0, t.trail.length, 5, 25);
      fill((t.hue + 15) % 360, 50, 100, a);
      text(t.text, p.x, p.y);
    }

    fill(t.hue, 80, 100, 95);
    text(t.text, t.x, t.y);
  }

  
  drawFloatingCamera(amplitude);
}

function drawVaporwaveSpectrum(spectrum, amplitude) {
  
  let elapsed = millis() - timeStart;
  let timeProgress = elapsed / timeDuration;
  if (timeProgress >= 1) {
    timeStart = millis();
    timeProgress = 0;
  }

  fill(260, 40, 15);
  rect(width / 2, height / 2, width, height);

  currentTimeY = lerp(height - 60, 60, timeProgress);
  let timeY = currentTimeY;
  let bandWidth = width / spectrum.length;
  hueStart = (hueStart + 0.4) % 360;

  // Waveform + Halo
  noFill();
  strokeWeight(2);
  beginShape();
  for (let i = 0; i < spectrum.length; i++) {
    let amp = spectrum[i];
    let x = i * bandWidth + bandWidth / 2;
    let y = timeY - amp * 0.4 + sin(frameCount * 0.05 + i * 0.3) * amplitude * 40;
    let h = (hueStart + i * 5) % 360;
    let b = map(amp, 0, 255, 60, 100);
    stroke(h, 80, b, 80);
    vertex(x, y);

    noStroke();
    let size = map(amp, 0, 255, 3, 10);
    fill(h, 80, 100, 70);
    ellipse(x, y, size, size);
  }
  endShape();

  // Floating particles
  for (let i = 0; i < spectrum.length; i += 3) {
    let amp = spectrum[i];
    let x = i * bandWidth + bandWidth / 2 + random(-4, 4);
    let y = timeY - amp * 0.4 + random(-6, 6);
    fill((hueStart + i * 5) % 360, 60, 90, 20);
    ellipse(x, y, random(2, 5), random(2, 5));
  }
}

function drawFloatingCamera(amplitude) {

  camBox.x += camBox.vx;
  camBox.y += camBox.vy;
  if (camBox.x < camBox.w / 2 || camBox.x > width - camBox.w / 2) camBox.vx *= -1;
  if (camBox.y < camBox.h / 2 || camBox.y > height - camBox.h / 2) camBox.vy *= -1;

  // visibly scaled up
  camBox.scale = map(amplitude, 0, 0.3, 0.85, 1.15);

  

  // camera
  tint(0, 0, 100, 90);//Controlling camera transparency to achieve light overlay
  image(
    cam, 
    camBox.x - camBox.w / 2 * camBox.scale, 
    camBox.y - camBox.h / 2 * camBox.scale, 
    camBox.w * camBox.scale, 
    camBox.h * camBox.scale);
  noTint();


}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function mousePressed() {
  let fs = fullscreen();
  fullscreen(!fs);
}